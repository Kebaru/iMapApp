//
//  ViewController.swift
//  MapApp
//
//  Created by Кардошевский ИСИП 20 on 28.03.2022.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var mapView:MKMapView!
    
    var itemMapFirst: MKMapItem!
    var itemMapSecond: MKMapItem!
    
    let manager: CLLocationManager = {
        let locationManager = CLLocationManager()
        
        locationManager.activityType = .fitness
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 1
        locationManager.showsBackgroundLocationIndicator = true
        locationManager.pausesLocationUpdatesAutomatically = true
        
        return locationManager
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        manager.delegate = self
        
        authorization()
        pinPosition()
    }
    
    func pinPosition(){
        let arrayLat = [62.03, 39.7]
        let arrayLon = [129.73, -104.99]
        
        for number in 0..<arrayLat.count{
            let point = MKPointAnnotation()
            point.title = "My point"
            point.coordinate = CLLocationCoordinate2D(latitude: arrayLat[number], longitude: arrayLon[number])
            mapView.addAnnotation(point)
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for location in locations {
            print(location.coordinate.latitude)
            print(location.coordinate.longitude)
        }
    }
    
    func authorization(){
        if CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            mapView.showsUserLocation = true
        }
        else{
            manager.requestWhenInUseAuthorization()
        }
    }

}

